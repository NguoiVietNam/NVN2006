#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "intp.h"     /* External Interrupt interface */
#include "timer.h"    /* Timer driver interface */
#include "stdio.h"    /* Standard IO library: sprintf */
#include "Glyph_API.h" 
#include <string.h>

/*  */
static int sw3_state=0;

void check_polling()
{
	if(0 == P7_bit.no6)
	{
		sw1++;
		sw1_0 = 0;
	}
	else
	{
		sw1 = 0;
		sw1_0++;
		flag_sw1 = 1;
		if(sw1_0 >= 2)
		both_flag = 1;
	}
	
	if(0 == P7_bit.no4)
	{
		sw2_0 = 0;		
		sw2++;
	}
	else
	{
		sw2 = 0;
		sw2_0++;
		flag_sw2 = 1;
		if(sw2_0 >= 2)
		both_flag = 1;
	}
	
	if(P7_bit.no5 == 0)
	{
		sw3_0 = 0;
		sw3++;
	}
	else
	{
		sw3 = 0;
		sw3_0++;
		flag_sw3 = 1;
	}
}

void switch_handle ()
{
	int i=0;
	if(sw1>=2&&flag_sw1==1)
	{
		if(sw3_state==1||state!=0)
		{
		flag=1;
		sw1_0=0;
		if(number>1)
		{
			state=2;
			number--;
		}
		else 
		{
			if(datanumber>1)
			state=4;
			else
			state=1;
			tmp=msecond;
		}
		}
		flag_sw1=0;
	}
	/////////////////////////
	
	if(sw2>=2&&flag_sw2==1)
	{
		if(sw3_state==1||state!=0)
		{
		flag=1;
		sw2_0=0;
		if(number<=(datanumber-1))
		{
			state=2;
			number++;
		}
			else 
		{
			if(datanumber>1)
			state=3;
			else
			state=1;
			tmp=msecond;
		}
		}
		flag_sw2=0;
	}
	/////////////////////////
	if(sw3>=2&&flag_sw3==1)
	{
		flag=1;
		sw3_0=0;
		if(sw3_state==0&&pause_flag==0)
		{
			timer_start();
			sw3_state=1;
			state = 1;
		}
		else if(sw3_state==1)
		{
			state =2;
			datanumber++;
			if(datanumber<=20)
			{
			data[datanumber-1].datano=msecond;
			data[datanumber-1].no=datanumber;
			}
			else
			{
			data_tmp.datano=msecond;
			data_tmp.no=datanumber;
			data_stack();
			}
			if(datanumber>=6)
			number=datanumber-5;
		}
		if(sw3_state==0&&pause_flag==1)
		{
			timer_start();
			pause_flag=0;
			sw3_state=1;
			state=2;
		}
		flag_sw3=0;
	}
	//////////////////////////
	if(flag_sw1==0&&flag_sw2==0&&both_flag==1)
	{
		if((state!=5)&&(pause_flag==0))
		{
		timer_stop();
		sw3_state=0;
		state=5;
		pause_flag=1;
		both_flag=0;
		}
		else if(pause_flag==1)
		{
			sw3_state=0;
			state=0;
			datanumber=0;
			number=0;
			msecond=0;
			ClearLCD();
			both_flag=0;
			for (i=1;i<=20;i++)
			{
				data[i].datano=0;
				data[i].no=0;
			}
		}
	}

}

void data_stack()
{
	int i=0;
	for (i=0;i<=18;i++)
	{
	data[i].datano=data[i+1].datano;
	data[i].no=data[i+1].no;
	}
	data[19].datano=data_tmp.datano;
	data[19].no=data_tmp.no;
}