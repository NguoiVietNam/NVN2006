/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2017 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : main.c
* Version      : 1.00
* Device(s)    : RL78/G14
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 14.04.2017 1.00    First Release
******************************************************************************/

/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
//#pragma interrupt INTIT timer_isr
#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "intp.h"     /* External Interrupt interface */
#include "timer.h"    /* Timer driver interface */
#include "stdio.h"    /* Standard IO library: sprintf */
#include "Glyph_API.h" 
#include <string.h>
/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/


/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/

/******************************************************************************
Private global variables and functions
******************************************************************************/
void r_main_userinit(void);
void convert_clock(unsigned int time, char *p);
void display_records (int i, char *p);

T_glyphHandle hlcd;
T_glyphError  result;

uint8_t g_time_update_flag;
uint16_t msecond;
uint16_t number;
uint16_t datanumber;
uint16_t tmp = 0;

char string_time[13];
char string_clock[13];

/* 'datatype' is declared in timer.h */
data_type data[20];
data_type data_tmp;

int pause_flag = 0;
int flag = 0, flag2 = 0;

/* 'sw1' use to count the amounts when switch1 is switched. */
int sw1 = 0;

/* 'sw2' use to count the amounts when switch2 is switched. */
int sw2 = 0;

/* 'sw3' use to count the amounts when switch3 is switched. */
int sw3 = 0;

/* 'sw1_0' use to count the amounts when switch1 is released. */
int sw1_0 = 0;

/* 'sw2_0' use to count the amounts when switch2 is released. */
int sw2_0 = 0;

/* 'sw3_0' use to count the amounts when switch3 is released. */
int sw3_0 = 0;

/* 'flag_sw1' use to check the switch1 is switched or not
   default is 1 (not switched); switched is 0; released is 1. It's helpful when the switch1 is switched and held*/
int flag_sw1;
int flag_sw2;
int flag_sw3;

/* 'both_flag' use to check the switch1 and swithc2 are switched or not
   default is 1 (not switched); switched is 0; released is 1. It's helpful when the switch1 is switched and held*/
int both_flag;

/******************************************************************************
* Function Name: main
* Description  : Main program
* Arguments    : none
* Return Value : none
******************************************************************************/
void main(void)
{
	/* Local time structure to temporary store the global time */
	time_t p_time;
	int i = 2;
	int j;
	
	r_main_userinit();
	number = 0;
	flag_sw1 = 1;
	flag_sw2 = 1;
	flag_sw3 = 1;
	both_flag = 1;
	datanumber = 0;
	/* Clear LCD display */
	ClearLCD();
	
	/* Print message to the first line of LCD */
	

	/* Initialize external interrupt for switches */
	//intp_init();

	/* Initialize timer driver */
	timer_init();
					
	/* Main loop - Infinite loop */
	while (1) 
	{
	check_polling();//Kiem tra nut
	switch_handle();//Xu ly ham sau khi kiem tra nut
	switch (state)
	{
	case 0:
		if(flag==1)
		ClearLCD();
		flag=0;
		result = GlyphSetXY(hlcd,20, LCD_LINE1); 
		GlyphString(hlcd, "pausing", strlen("pausing"));
		convert_clock(msecond,&string_clock);
		result = GlyphSetXY(hlcd,20, LCD_LINE2); 
		GlyphString(hlcd, string_clock, strlen(string_clock));
		break;
	case 1:
		if(flag==1)
		ClearLCD();
		flag=0;
		if(200<(msecond-tmp)&&tmp!=0)
		{
			if(flag2==2)
			ClearLCD();
			flag2=0; 
			result = GlyphSetXY(hlcd,20, LCD_LINE1); 
			GlyphString(hlcd, "running", strlen("running"));
		}
		else if(200>(msecond-tmp)&&tmp!=0)
		{
			flag2=2;
			result = GlyphSetXY(hlcd,20, LCD_LINE1); 
			GlyphString(hlcd, "no record", strlen("no record"));
		}
		if(tmp==0)
		{
		result = GlyphSetXY(hlcd,20, LCD_LINE1); 
		GlyphString(hlcd, "running", strlen("running"));
		}
		convert_clock(msecond,&string_clock);
		result = GlyphSetXY(hlcd,20, LCD_LINE2); 
		GlyphString(hlcd, string_clock, strlen(string_clock));
		
		break;
	case 2: case 3: case 4:case 5:
		if(flag==1)
		ClearLCD();
		flag=0; 
		switch (state)
		{
			case 2:
				result = GlyphSetXY(hlcd,20, LCD_LINE1);
				if(pause_flag==1)
				GlyphString(hlcd, "pausing", strlen("pausing"));
				else
				GlyphString(hlcd, "running", strlen("running"));
				break;
			case 3:
				if ( 200 < (msecond-tmp))
			{
				if(flag2==2)
				ClearLCD();
				flag2=0; 
				result = GlyphSetXY(hlcd,20, LCD_LINE1);
				GlyphString(hlcd, "running", strlen("running"));
				break;
			}
			else 
			{
				flag2=2;
				result = GlyphSetXY(hlcd,5, LCD_LINE1);
				GlyphString(hlcd, "Last_record", strlen("Last_record"));
				break;
			}
			case 4:
				if ( 200 < (msecond-tmp))
			{
				if(flag2==2)
				ClearLCD();
				flag2=0; 
				result = GlyphSetXY(hlcd,20, LCD_LINE1);
				GlyphString(hlcd, "running", strlen("running"));
				break;
			}
			else 
			{
				flag2=2;
				result = GlyphSetXY(hlcd,0, LCD_LINE1);
				GlyphString(hlcd, "First_record", strlen("First_record"));
				break;
			}
			case 5:
				if(flag==1)
				ClearLCD();
				flag=0;
				result = GlyphSetXY(hlcd,20, LCD_LINE1); 
				GlyphString(hlcd, "pausing", strlen("pausing"));
				break;
		}
		convert_clock(msecond,&string_clock);
		result = GlyphSetXY(hlcd,20, LCD_LINE2); 
		GlyphString(hlcd, string_clock, strlen(string_clock));
		j=number;
		for (j=number;j<=datanumber;j++)
		{
			if (i<8)
			{
				
				if(data[j].datano!=0)
				{
				data_convert(data[j],&string_time);
				if((i>=2)&&(i<=7))
				display_records(i,&string_time);
				i++;
				}
				
			
			}
		}
		i=2;
		break;
	}
		
	}
}

/******************************************************************************
* Function Name: r_main_userinit
* Description  : User initialization routine
* Arguments    : none
* Return Value : none
******************************************************************************/
void r_main_userinit(void)
{
	uint16_t i;

	/* Enable interrupt */
	EI();

	/* Output a logic LOW level to external reset pin*/
	P13_bit.no0 = 0;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Generate a raising edge by ouput HIGH logic level to external reset pin */
	P13_bit.no0 = 1;
	for (i = 0; i < 1000; i++)
	{
		NOP();
	}

	/* Output a logic LOW level to external reset pin, the reset is completed */
	P13_bit.no0 = 0;
	
	/* Initialize SPI channel used for LCD */
	R_SPI_Init(SPI_LCD_CHANNEL);
	
	/* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
	R_SPI_SslInit(
		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
		(unsigned char *)&P14,   /* Select Port register */
		(unsigned char *)&PM14,  /* Select Port mode register */
		5,                       /* Select pin index in the port */
		0,                       /* Configure CS pin active state, 0 means active LOW level  */
		0                        /* Configure CS pin active mode, 0 means active per transfer */
	);
	result = GlyphOpen (&hlcd, 0);        /* Open the Glyph API */
	result = GlyphNormalScreen(hlcd);   /* Sets up the normal LCD Screen */

	result =GlyphClearScreen(hlcd);                 /* Clears the LCD Screen */
	      /* Set writing position to (0, 0) */
	/* Initialize LCD driver */
	InitialiseLCD();	
}
void data_convert (data_type data,char *p)
{
	unsigned int star,second,minute;
	star = (data.datano%100);	
	second = (data.datano/100)%60;
	minute = (data.datano/100)/60;
	*(p+0) = '#';
	*(p+1) = (data.no)/10+48;
	*(p+2) = (data.no)%10+48;
	*(p+3) = ' ';
	*(p+4) = minute/10+48;
	*(p+5) = minute%10+48;
	*(p+6) = ':';
	*(p+7) = second/10+48;
	*(p+8) = second%10+48;
	*(p+9) = ':';
	*(p+10) = star/10+48;
	*(p+11) = star%10+48;
	*(p+12) = '\0';
}

void display_records (int i,char *p)
{
	int a;
	switch (i)
	{
	case 0:
		a=LCD_LINE1;
		break;
	case 1:
		a=LCD_LINE2;
		break;
	case 2:
		a=LCD_LINE3;
		break;
	case 3:
		a=LCD_LINE4;
		break;
	case 4:
		a=LCD_LINE5;
		break;
	case 5:
		a=LCD_LINE6;
		break;
	case 6:
		a=LCD_LINE7;
		break;
	case 7:
		a=LCD_LINE8;
		break;
	}
	result = GlyphSetXY(hlcd,0, a); 
	GlyphString(hlcd, p, strlen(p));
}

void convert_clock(unsigned int time,char *p)
{
	unsigned int star,second,minute;
	star=(time%100);	
	second=(time/100)%60;
	minute=(time/100)/60;
	*(p+0)=minute/10+48;
	*(p+1)=minute%10+48;
	*(p+2)=':';
	*(p+3)=second/10+48;
	*(p+4)=second%10+48;
	*(p+5)=':';
	*(p+6)=star/10+48;
	*(p+7)=star%10+48;
	*(p+8)='\0';
}

/******************************************************************************
End of file
******************************************************************************/

