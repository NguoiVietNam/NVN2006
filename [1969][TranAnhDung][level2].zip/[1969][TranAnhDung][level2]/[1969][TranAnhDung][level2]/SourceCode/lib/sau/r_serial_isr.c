/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : r_serial_isr.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 02.07.2015 1.00    First Release
******************************************************************************/
/******************************************************************************
Pragma directive
******************************************************************************/
#pragma interrupt INTCSI21 r_csi21_interrupt

/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#include "r_macro.h"
#include "r_serial.h"

/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/
extern volatile uint8_t * gp_csi21_rx_address; /* csi21 receive buffer address */
extern volatile uint16_t  g_csi21_rx_length;   /* csi21 receive data length */
extern volatile uint16_t  g_csi21_rx_count;    /* csi21 receive data count */
extern volatile uint8_t * gp_csi21_tx_address; /* csi21 send buffer address */
extern volatile uint16_t  g_csi21_send_length; /* csi21 send data length */
extern volatile uint16_t  g_csi21_tx_count;    /* csi21 send data count */

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/
volatile uint8_t G_CSI21_SendingData   = 0;
volatile uint8_t G_CSI21_ReceivingData = 0;
void (* G_CSI21_SendEndCallback)(void);
void (* G_CSI21_ReceiveEndCallback)(void);

/******************************************************************************
Private global variables and functions
******************************************************************************/
/******************************************************************************
* Function Name: r_csi21_interrupt
* Description  : This function is INTCSI21 interrupt service routine.
* Arguments    : none
* Return Value : none
******************************************************************************/
__interrupt static void r_csi21_interrupt(void)
{
    uint8_t err_type;

    err_type = (uint8_t)(SSR11 & _0001_SAU_OVERRUN_ERROR);
    SIR11 = (uint16_t)err_type;

    if (1U == err_type)
    {
        r_csi21_callback_error(err_type);    /* overrun error occurs */
    }
    else
    {
        if (g_csi21_tx_count > 0U)
        {
            *gp_csi21_rx_address = SIO21;
            gp_csi21_rx_address++;
            SIO21 = *gp_csi21_tx_address;
            gp_csi21_tx_address++;
            g_csi21_tx_count--;
        }
        else 
        {
            if (0U == g_csi21_tx_count)
            {
                *gp_csi21_rx_address = SIO21;
            }

            r_csi21_callback_sendend();    /* complete send */
            r_csi21_callback_receiveend();    /* complete receive */
        }
    }
}

/******************************************************************************
* Function Name: r_csi21_callback_receiveend
* Description  : This function is a callback function when CSI21 finishes reception.
* Arguments    : none
* Return Value : none
******************************************************************************/
static void r_csi21_callback_receiveend(void)
{
	/* Clear receiving status flag */
	G_CSI21_ReceivingData = 0;

	/* Invoke callback function */
    if (G_CSI21_ReceiveEndCallback)
    {
        G_CSI21_ReceiveEndCallback();
    }
}

/******************************************************************************
* Function Name: r_csi21_callback_error
* Description  : This function is a callback function when CSI21 reception error occurs.
* Arguments    : none
* Return Value : none
******************************************************************************/
static void r_csi21_callback_error(uint8_t err_type)
{
	/* Not implemented in this course */
}

/******************************************************************************
* Function Name: r_csi21_callback_sendend
* Description  : This function is a callback function when CSI21 finishes transmission.
* Arguments    : none
* Return Value : none
******************************************************************************/
static void r_csi21_callback_sendend(void)
{
	/* Clear sending status flag */
	G_CSI21_SendingData = 0;

	/* Invoke callback function */
    if (G_CSI21_SendEndCallback)
    {
        G_CSI21_SendEndCallback();
    }
}

/******************************************************************************
End of file
******************************************************************************/

