/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : timer.c
* Version      : 1.00
* Device(s)    : 
* Tool-Chain   : 
* H/W Platform : 
* Description  : 
******************************************************************************
* History : DD.MM.YYYY Version Description
*         : 01.07.2015 1.00    First Release
******************************************************************************/


/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
#pragma interrupt INTIT r_it_interrupt
#pragma interrupt INTTM00 r_tau_interrupt
#include "r_macro.h"
#include "timer.h"

/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/
#define TURN_ON	1
#define TURN_OFF 0
#define PAUSE_STAGE		1
#define RUN_STAGE		2
extern uint8_t mode_change_flag;
extern uint8_t display_record_flag;
extern uint8_t display_2s_flag;
extern uint8_t time_change_flag;
extern uint8_t stage;
extern uint8_t stage_temp;
extern uint8_t store;
extern unsigned int centisecond;
/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/
/******************************************************************************
* Function Name: timer_init
* Description  : Initialize interval timer driver
* Arguments    : none
* Return Value : none
******************************************************************************/
void timer_init(void)
{
	/* Supply clock to the interval timer */
    RTCEN = 1U;
	/* Disable interval timer operation */
    ITMC = 0x0000U;

	/* Disable interval timer interrupt */
    ITMK = 1U;
	/* Clear interval timer interrupt flag */
    ITIF = 0U;

    /* Set INTIT level 2 priority */
    ITPR1 = 1U;
    ITPR0 = 0U;

	/* Set interval timer compare value */
	/* The compare value is calculated for 100ms interval */
    ITMC = 0x0CCCU;
}

/******************************************************************************
* Function Name: timer_start
* Description  : Start interval timer
* Arguments    : none
* Return Value : none
******************************************************************************/
void timer_start(void)
{
	/* Clear interval timer interrupt flag */
    ITIF = 0U;
	/* Enable interval timer interrupt */
    ITMK = 0U;
	/* Enable interval timer operation */
    ITMC |= 0x8000U;
} 
/******************************************************************************
* Function Name: timer_stop
* Description  : Stop interval timer
* Arguments    : none
* Return Value : none
******************************************************************************/
void timer_stop(void)
{
	/* Disable interval timer interrupt */
    ITMK = 1U;
	/* Clear interval timer interrupt flag */
    ITIF = 0U;
	/* Enable interval timer operation */
    ITMC &= 0x7FFFU;
}
 void R_TAU0_Create(void)
{
    TAU0EN = 1U;    /* supply timer clock */
    TT0    = 1U;    /* disable timer operation */
    TMMK00 = 1U;    /* disable timer interrupt */
    TMIF00 = 0U;    /* clear timer interrupt flag */

    TPS0   = 0X0009U;    /* Select clock source: /2^9 */

    TDR00 = 0x186AU;    /* Configure timer data register */
}
  void R_TAU0_Start(void)
{
    TS0    = 1U;    /* enable timer operation */
    TMIF00 = 0U;    /* clear timer interrupt flag */
    TMMK00 = 0U;    /* enable timer interrupt */
}
 void R_TAU0_Stop(void)
{
    TMMK00 = 1U;    /* disable timer interrupt */
    TMIF00 = 0U;    /* clear timer interrupt flag */
    TT0    = 1U;    /* disable timer operation    */
}

 __interrupt static void r_tau_interrupt(void)
{
    /* Start user code. Do not edit comment generated here */
    static int count=0;
    count=count+10;
    if(count>=200)
    {
    	count=0;
	stage=store;
	mode_change_flag=TURN_ON;
	time_change_flag=TURN_ON;
	display_record_flag=TURN_ON;
    }	                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
    /* End user code. Do not edit comment generated here */
}
/******************************************************************************
* Function Name: r_it_interrupt
* Description  : update time
* Arguments    : none
* Return Value : none
******************************************************************************/
__interrupt static void r_it_interrupt(void)
{
    /* Start user code. Do not edit comment generated here */

		static unsigned int k1=0;
		if(display_2s_flag==TURN_ON)
    		{	k1=k1+10;
			if(k1>=200)
			{
				k1=0;
				stage=store;
				mode_change_flag=TURN_ON;
				display_record_flag=TURN_ON;
				display_2s_flag=TURN_OFF;
			}
		}
    		centisecond=centisecond+10;
    		time_change_flag=TURN_ON;
	
    /* End user code. Do not edit comment generated here */
}

/******************************************************************************
Private global variables and functions
******************************************************************************/

/******************************************************************************
End of file
******************************************************************************/

