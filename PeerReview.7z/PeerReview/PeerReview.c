/*
 ============================================================================
 Name        : PeerReview.c
 Author      : ThanhDinh
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int error(int code)
{
    switch(code)
    {
    case 1:
        printf("Invalid input \n");
        break;
    case 2:
        printf("Please input positive numbers \n");
        break;
    case 3:
        printf("the input is larger than 6000 \n");
        break;
    case 4:
        printf("the minimun number of input msut be 3 \n");
        break;

    }
    return 0;
}

int input( int *input_array)
{
    int i;
    int n = 0;
    int m;
    char temp[5] ;
    printf("Please input the numbers \n");
    while (n != 10)
    {
        printf("Nhap so thu %d: \n", n+1);
        scanf("%4s",temp);
        m = strlen(temp);
        if ( temp[0] == '-')
        {
            error(2);
            return -1;
        }
        else if (( temp[0] == 'E') && (temp[1] == 'N') && (temp[2] == 'D'))
        {
            if (n < 3)
            {
                error(4);
                return -1;
            }
            else
            {
                break;
            }
        }
        else
        {
            for (i = m; i >0; i--)
            {
                if ((temp[i-1] <= '9') && (temp[i-1] >= '0'))
                {
                	input_array[n] += (temp[i-1]-'0')*pow(10,m-i);
                    printf("%d \n",input_array[n]);
                }
                else
                {
                    error(1);
                    return -1;
                }
            }
        }
        if (input_array[n] > 6000)
        {
            error(3);
            return -1;
        }
        n++;
    }

    return n;
}

int plus( int *input_array, int total_number, int input_number, int *result)
{
    int sum = 0;
    int i;
    for (i =0; i < input_number; i++)
    {
        sum += input_array[i];
    }
    result[0] = sum;
    printf("1:%d\n",result[0]);
    sum = 0;
    for (i =input_number ; i < total_number; i++)
    {
        sum += input_array[i];
    }
    result[1] = sum;
    printf("2:%d\n",result[1]);
    return 0;
}

int main(void)
{
    int *input_array = (int*)calloc(55,sizeof(int));
    int result[2];
    int total_number;
    int i,j,temp;
    for ( i = 0; i < 55; i++)
    {
    	input_array[i] = 0;
    }
    total_number = input(input_array);
    if (total_number == -1)
    {
    	return 0;
    }
    j = 0;
    printf("total number: %d\n",total_number);
    for( i =0; i < total_number - 1; i++)
    {
        plus(input_array, total_number, i+1, result);
        if (i == 0)
        {
            temp = abs(result[0] - result[1]);
            j = i;
        }
        else if (abs(result[0] - result[1]) < temp)
        {
            temp = abs(result[0] - result[1]);
            j = i;
        }
        else
        {

        }
    }

    printf("Minimum difference: %d \n",temp);
    printf("Subs group 1 \n");
    for (i = 0; i <= j; i++)
    {
        printf("%d \n", input_array[i]);
    }
    printf("Subs group 2 \n");
    for (i = j+1; i <= (total_number - 1) ; i++)
    {
        printf("%d\n", input_array[i]);
    }
    free(input_array);
    return 0;

}
