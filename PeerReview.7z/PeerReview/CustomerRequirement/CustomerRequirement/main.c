﻿#define CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <math.h>

void main(){
	int i;
	int j = 0, n, temp = 0;
	int SeriesNumber[10];
	int sumfront[9] = {0};
	int sumback[9] = {0};
	int sum = 0;
	int min = 0;

	/* Input data of array*/
	do {
		printf("Nhap so luong phan tu co trong mang <tu 3 den 10 phan tu>\n");
		scanf("%d", &n);
		flushall();
	} while(n < 3 || n > 10);
	
	printf("Nhap gia tri cua cac phan tu co trong mang <tu 0 den 99>\n");
	for (i = 0; i < n; i++)
	{
		printf("SeriesNumber[%d] ", i);
		scanf("%d", &SeriesNumber[i]);	
		//printf("%d", SeriesNumber[i]);
		flushall();
		if ((SeriesNumber[i] >= 0 && SeriesNumber[i] <= 99))
		{
			;
		}
		else
		{
			printf("Ban da nhap sai, vui long nhap lai.\n");
			i--;
		}
		
	}

	
	/* Print all of index in your array */
	printf("Mang ban da nhap:\n");
	for(i = 0; i < n; i++)
	{
		printf("%d\t", SeriesNumber[i]);
	}

	/* Print sum of all input */
	for(i = 0; i < n; i++)
	{
		sum += SeriesNumber[i];
	}
	printf("\nTong gia tri cua cac phan tu ban da nhap: %d\n", sum);

	/* Calculate sumfront */
	for (i = 0; i < n-1; i++)
	{
		sumfront[i] = sumfront[temp] + SeriesNumber[i];
		temp = i;
	}
	temp = 0;	//reset temp

	/* Print sumfront */		//function for test, not include
	printf("\nSum Front:\n");
	for(i = 0; i < n-1; i++)
	{
		printf("%d\t", sumfront[i]);
	}

	/* Calculate sumback */
	for (i = 0; i < (n-1); i++)
	{
			sumback[i] = sum - sumfront[i];
	}

	/* Print sumback */			//function for test, not include
	printf("\nSum Back:\n");
	for(i = 0; i < n-1; i++)
	{
		printf("%d\t", sumback[i]);
	}

	/* Find sub-group and index of min sub-group */
	for (i = 0; i <= (n-2); i++)
	{
		if (i == 0)
		{
			min = abs(sumfront[i] - sumback[i]);
			printf("\nMin sub-group0: %d", min);	//for test, not include
		}
		else
		{
			if ( abs(sumfront[i] - sumback[i]) <= min)   //change < to <=
			{
				min = abs(sumfront[i] - sumback[i]);
				printf("\nMin sub-group1: %d", min);	//for test, not include
				temp = i;
			}
			else
			{
				//min = min;		//just for clear, not include
				printf("\nMin sub-group2: %d", min);	//for test, not include
				//temp = i;
			}
		}
	}

	/* Print min sub-group and Min index of min sub-group */
	printf("\nMin sub-group: %d", min);
	printf("\nMIN's position: %d",temp);		//for test, not include
	printf("\nMin index of Min Group: %d\t%d", sumfront[temp], sumback[temp]);

	_getch();
}